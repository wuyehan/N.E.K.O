"""
Bilibili 弹幕插件 (Bilibili-Danmaku) - 增强版（集成背景LLM系统）

功能：
- 监听 B站直播间弹幕，通过背景LLM系统智能过滤和摘要后推送给AI
- 四象限智能分级：紧急+重要事件立即推送，重要事件进入聚合池
- 用户画像持久化：跨会话积累用户价值数据
- 智能摘要生成：云端LLM+本地规则双模摘要
- 熔断降级机制：云端API故障时自动降级本地规则
- SC、高价值礼物即时推送通知给AI，触发语音感谢
- AI 可通过 send_danmaku 发送弹幕到直播间（需登录）
- 自动读取 NEKO 项目已保存的 B站 Cookie（无需重复登录）

入口：
- set_room_id      更改监听的直播间
- set_interval     更改推送给 AI 的弹幕间隔（5s ~ 180s）
- send_danmaku     发送弹幕到直播间（需登录）
- get_danmaku      获取最新弹幕
- get_status       获取插件状态
- save_credential  保存 B站登录凭据
- clear_credential 清除 B站登录凭据
- reload_credential 重新加载凭据
- connect / disconnect 开始/停止监听

背景LLM系统API：
- get_summary_config     获取背景LLM配置
- update_summary_config  更新配置
- get_user_profile       查询单个用户画像
- clear_user_profiles    清空画像数据（慎用）
- test_summary_local     测试本地摘要效果
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, List

from plugin.sdk.plugin import (
    NekoPluginBase,
    neko_plugin,
    plugin_entry,
    lifecycle,
    timer_interval,
    Ok,
    Err,
    SdkError,
    get_plugin_logger,
)

# 常量定义
MIN_INTERVAL = 5        # 最小推送间隔（秒）
MAX_INTERVAL = 180      # 最大推送间隔（秒）
UI_URL = "http://localhost:48916/plugin/bilibili_danmaku/ui/"

# ── 同步 helper（避免 async def 内直接调 subprocess 阻塞事件循环）────────────
import logging as _logging
_logger = _logging.getLogger(__name__)

# ==========================================
# 本地凭据类（替代 bilibili_api.Credential，无外部依赖）
# ==========================================
class _BiliCredential:
    """轻量 B站凭据容器，仅存储 Cookie 字段供 DanmakuListener 使用"""

    def __init__(
        self,
        sessdata: str = "",
        bili_jct: str = "",
        buvid3: str = "",
        dedeuserid: str = "",
    ):
        self.sessdata = sessdata
        self.bili_jct = bili_jct
        self.buvid3 = buvid3
        self.dedeuserid = dedeuserid


# ==========================================
# 插件级加密 Cookie 工具（Fernet，独立密钥）
# ==========================================
_PLUGIN_CRED_FILE = "bili_credential.enc"
_PLUGIN_KEY_FILE  = "bili_credential.key"


async def _get_fernet(data_dir: Path):
    """获取或生成插件本地 Fernet 实例，密钥存 data_dir/<_PLUGIN_KEY_FILE>"""
    from cryptography.fernet import Fernet
    key_path = data_dir / _PLUGIN_KEY_FILE
    if key_path.exists():
        key = await asyncio.to_thread(key_path.read_bytes)
    else:
        key = Fernet.generate_key()
        await asyncio.to_thread(data_dir.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(key_path.write_bytes, key)
        if sys.platform != "win32":
            await asyncio.to_thread(os.chmod, str(key_path), 0o600)
    return Fernet(key)


async def _save_credential_encrypted(data_dir: Path, cred: dict) -> bool:
    """加密保存凭据字典到 data_dir/<_PLUGIN_CRED_FILE>"""
    try:
        fernet = await _get_fernet(data_dir)
        enc = fernet.encrypt(json.dumps(cred, ensure_ascii=False).encode("utf-8"))
        cred_path = data_dir / _PLUGIN_CRED_FILE
        await asyncio.to_thread(cred_path.write_bytes, enc)
        if sys.platform != "win32":
            await asyncio.to_thread(os.chmod, str(cred_path), 0o600)
        return True
    except Exception:
        return False


async def _load_credential_encrypted(data_dir: Path) -> Optional[Dict[str, str]]:
    """从 data_dir/<_PLUGIN_CRED_FILE> 解密读取凭据字典，失败返回 None"""
    try:
        cred_path = data_dir / _PLUGIN_CRED_FILE
        if not cred_path.exists():
            return None
        key_path = data_dir / _PLUGIN_KEY_FILE
        if not key_path.exists():
            return None
        from cryptography.fernet import Fernet
        key = await asyncio.to_thread(key_path.read_bytes)
        fernet = Fernet(key)
        enc_data = await asyncio.to_thread(cred_path.read_bytes)
        dec = fernet.decrypt(enc_data).decode("utf-8")
        return json.loads(dec)
    except Exception:
        return None


async def _delete_credential_files(data_dir: Path) -> list[str]:
    """删除插件本地凭据文件，返回删除失败的文件名列表"""
    failed = []
    for fname in (_PLUGIN_CRED_FILE, _PLUGIN_KEY_FILE):
        p = data_dir / fname
        if p.exists():
            try:
                await asyncio.to_thread(p.unlink)
            except Exception:
                failed.append(fname)
    return failed

try:
    from .user_profile import UserProfileStore
    from .filter_pipeline import FilterPipeline, Quadrant, FilterResult
    from .aggregator import AggregationBuffer, AggregatedEvent
    from .summary import (
        SummaryOrchestrator, 
        OrchestratorConfig,
        LocalEngine,
        CloudClient,
        CircuitBreaker
    )
    BACKGROUND_LLM_AVAILABLE = True
except ImportError as e:
    _logger.warning("背景LLM模块导入失败: %s, 将使用原始模式", e)
    BACKGROUND_LLM_AVAILABLE = False

# ── B站 认证/内容服务 ──────────────────────────────────────────────────
from .bili_auth_service import BiliAuthService
from .bili_content_service import BiliContentService

# ── 同步 helper（避免 async def 内直接调 subprocess 阻塞事件循环）────────────
def _open_url_in_browser(url: str) -> None:
    """在默认浏览器打开 URL（同步调用，仅供 asyncio.to_thread 使用）"""
    if sys.platform == "win32":
        os.startfile(url)
    elif sys.platform == "darwin":
        subprocess.run(["open", url])
    else:
        subprocess.run(["xdg-open", url])


@neko_plugin
class BiliDanmakuPlugin(NekoPluginBase):
    """Bilibili 弹幕监听插件（增强版）"""

    # 插件元信息
    name = "bilibili_danmaku"
    version = "1.1.0"  # 版本升级
    description = "Bilibili 弹幕监听插件，集成背景LLM智能摘要系统"
    author = "NEKO Team"
    passive = True  # 被动插件（不主动调用 AI）

    def __init__(self, ctx: Any):
        super().__init__(ctx)
        self.logger = get_plugin_logger(__name__)
        
        # 基础配置
        self._room_id = 123456  # 默认直播间ID
        self._interval = 30  # 推送间隔（秒），默认30秒
        self._target_lanlan = "皖萱"  # 目标AI名称
        self._danmaku_max_length = 20  # 弹幕最大长度（B站限制）
        
        # 主人账号识别
        self._master_bili_uid = 0
        self._master_bili_name = ""
        
        # 监听器状态
        self._listener = None
        self._connecting = False
        self._last_push_time = datetime.now().timestamp()
        self._total_pushed = 0
        
        # 队列系统
        self._danmaku_queue = deque(maxlen=200)  # AI推送队列
        self._sc_queue = deque(maxlen=50)  # SC队列
        self._gift_queue = deque(maxlen=100)  # 礼物队列
        self._ui_queue = deque(maxlen=500)  # UI展示队列
        
        # 背景LLM系统组件
        self._background_llm_enabled = False
        self._user_profile_store = None
        self._filter_pipeline = None
        self._aggregation_buffer = None
        self._summary_orchestrator = None
        
        # 旧版弹幕过滤器（用于非背景LLM模式）
        self._filter = None
        
        # UI展示队列
        self._ui_danmaku_queue: deque = deque(maxlen=500)
        self._ui_gift_queue: deque = deque(maxlen=100)
        self._ui_sc_queue: deque = deque(maxlen=50)
        
        # 统计
        self._total_received = 0
        self._total_filtered = 0
        self._last_push_ts: float = 0.0
        self._push_cooldown: float = 5.0
        self._push_sc_threshold: int = 1
        self._push_gift_threshold: float = 1.0
        
        # 主人账号
        self._master_display_name: str = "主人"
        self._logged_in_bili_uid: int = 0
        self._logged_in_matches_master: bool = False
        self._master_display_name_fetched: bool = False
        
        # B站登录
        self._bilibili_credential = None
        self._is_logged_in: bool = False
        
        # AI代写锁
        self._bili_ai_turn_locks: dict = {}
        self._pending_push_tasks: set = set()
        self._pending_restart_task = None
        
        # 后台任务
        self._listen_task = None
        
        # B站 认证/内容服务（在 __init__ 中创建，on_startup 时初始化凭据提供者）
        self._auth_service: Optional[BiliAuthService] = None
        self._content_service: Optional[BiliContentService] = None
        
        # 加载配置
        self._load_config()

    async def _open_plugin_ui(self) -> Dict[str, Any]:
        """在浏览器中打开弹幕控制台"""
        await asyncio.to_thread(_open_url_in_browser, UI_URL)
        self.logger.info(f"已在浏览器中打开: {UI_URL}")
        return {
            "success": True,
            "url": UI_URL,
            "message": "已在浏览器打开弹幕控制台",
        }

    # ==========================================
    # 配置加载/保存
    # ==========================================

    async def _load_plugin_config(self):
        """从插件 data/config.json 加载配置"""
        config_path = self.data_path("config.json")
        if config_path.exists():
            try:
                cfg = await asyncio.to_thread(self._read_json, config_path)
                self._room_id = int(cfg.get("room_id", 0))
                raw_interval = int(cfg.get("interval_seconds", 30))
                self._interval = max(MIN_INTERVAL, min(MAX_INTERVAL, raw_interval))
                self._target_lanlan = str(cfg.get("target_lanlan", "")).strip()
                self._danmaku_max_length = int(cfg.get("danmaku_max_length", 20))
                self._master_bili_uid = int(cfg.get("master_bili_uid", 0) or 0)
                self._master_bili_name = str(cfg.get("master_bili_name", "")).strip()
                self._danmaku_max_length = max(1, min(20, self._danmaku_max_length))
                self.logger.info(f"已加载配置: room_id={self._room_id}, interval={self._interval}s")
            except Exception as e:
                self.logger.warning(f"加载配置失败，使用默认值: {e}")
        else:
            await self._save_plugin_config()

    async def _save_plugin_config(self):
        """保存配置到 data/config.json"""
        config_path = self.data_path("config.json")
        await asyncio.to_thread(config_path.parent.mkdir, parents=True, exist_ok=True)
        cfg = {
            "room_id": self._room_id,
            "interval_seconds": self._interval,
            "target_lanlan": self._target_lanlan,
            "danmaku_max_length": self._danmaku_max_length,
            "master_bili_uid": self._master_bili_uid,
            "master_bili_name": self._master_bili_name,
        }
        await asyncio.to_thread(self._write_json, config_path, cfg)

    @staticmethod
    def _read_json(path: Path) -> dict:
        """同步读取 JSON（供 asyncio.to_thread 使用）"""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _write_json(path: Path, data: dict) -> None:
        """同步写入 JSON（供 asyncio.to_thread 使用）"""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    # ==========================================
    # B站凭据
    # ==========================================

    async def _load_bilibili_credential(self):
        """从插件本地加密存储或 NEKO 全局凭据文件读取 B 站 Cookie"""
        # 优先读插件自己保存的加密 Cookie
        try:
            local_cred = await _load_credential_encrypted(self.data_path())
            if local_cred and local_cred.get("SESSDATA"):
                self._bilibili_credential = _BiliCredential(
                    sessdata=local_cred.get("SESSDATA", ""),
                    bili_jct=local_cred.get("bili_jct", ""),
                    buvid3=local_cred.get("buvid3", ""),
                    dedeuserid=local_cred.get("DedeUserID", ""),
                )
                self._is_logged_in = True
                self._refresh_logged_in_master_conflict()
                self.logger.info("✅ 已读取插件本地加密凭据，使用登录模式")
                return
        except Exception as e:
            self.logger.warning(f"读取插件本地凭据失败: {e}")

        self._bilibili_credential = None

        # Fallback：读取 NEKO 全局保存的 B 站 Cookie
        try:
            from utils.cookies_login import load_cookies_from_file
            cookies = load_cookies_from_file("bilibili")
            if cookies and cookies.get("SESSDATA"):
                self._bilibili_credential = _BiliCredential(
                    sessdata=cookies.get("SESSDATA", ""),
                    bili_jct=cookies.get("bili_jct", ""),
                    buvid3=cookies.get("buvid3", ""),
                    dedeuserid=cookies.get("DedeUserID", ""),
                )
                self._is_logged_in = True
                self._refresh_logged_in_master_conflict()
                self.logger.info("✅ 已读取 NEKO 全局 B站凭据，使用登录模式")
            else:
                self._is_logged_in = False
                self._logged_in_bili_uid = 0
                self._logged_in_matches_master = False
                self.logger.info("👤 未找到 B站凭据，使用游客模式")
        except Exception as e:
            self._is_logged_in = False
            self._logged_in_bili_uid = 0
            self._logged_in_matches_master = False
            self.logger.warning(f"读取 B站凭据失败: {e}，使用游客模式")

    def _refresh_logged_in_master_conflict(self) -> None:
        """刷新登录账号与主人账号的匹配状态"""
        try:
            self._logged_in_bili_uid = int(getattr(self._bilibili_credential, "dedeuserid", 0) or 0)
        except (TypeError, ValueError):
            self._logged_in_bili_uid = 0
        self._logged_in_matches_master = bool(
            self._is_logged_in and self._master_bili_uid > 0 and self._logged_in_bili_uid == self._master_bili_uid
        )

    # ==========================================
    # 过滤器初始化
    # ==========================================

    async def _init_filter(self):
        """初始化弹幕过滤器"""
        if BACKGROUND_LLM_AVAILABLE and self._background_llm_enabled:
            # 背景LLM模式已自行初始化过滤流水线
            return
        # 非背景LLM模式：初始化旧版过滤器（从 filter.py 导入）
        try:
            from .filter import DanmakuFilter
        except ImportError:
            self.logger.warning("DanmakuFilter 不可用，跳过过滤器初始化")
            return
        filter_cfg_path = self.data_path("filter_config.json")
        filter_cfg = {}
        if filter_cfg_path.exists():
            try:
                filter_cfg = await asyncio.to_thread(self._read_json, filter_cfg_path)
            except Exception:
                pass
        config = {
            "is_logged_in": self._is_logged_in,
            "filter": filter_cfg,
        }
        self._filter = DanmakuFilter(config)
        self.logger.info(f"过滤器已初始化: {getattr(self._filter, 'describe_mode', lambda: 'unknown')()}")

    # ==========================================
    # B站 API 结果包装
    # ==========================================

    def _summarize_bili_payload(self, payload: object) -> str:
        """从 B站 API 返回的 payload 中提取摘要文本"""
        if isinstance(payload, dict):
            for key in ("message", "next_step", "status"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
            return json.dumps(payload, ensure_ascii=False)[:1200]
        return str(payload)

    def _bili_ok(self, payload: Dict[str, Any]) -> Ok:
        """包装 B站 API 成功结果，前端 callPlugin 期望 {success, summary, result} 结构"""
        return Ok({"success": True, "summary": self._summarize_bili_payload(payload), "result": payload})

    def _bili_err(self, exc: Exception) -> Err:
        """包装 B站 API 错误结果"""
        return Err(SdkError(str(exc)))

    # ==========================================
    # 监听控制
    # ==========================================

    async def _stop_listening(self):
        """停止弹幕监听"""
        self._connecting = False
        if self._listener and getattr(self._listener, 'is_running', lambda: False)():
            await self._listener.stop()
        if self._listen_task and not self._listen_task.done():
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass
        self._listener = None
        self._listen_task = None
        # 清空所有缓冲队列
        self._danmaku_queue.clear()
        self._sc_queue.clear()
        self._gift_queue.clear()
        if hasattr(self, '_ui_danmaku_queue'):
            self._ui_danmaku_queue.clear()
        if hasattr(self, '_ui_gift_queue'):
            self._ui_gift_queue.clear()
        if hasattr(self, '_ui_sc_queue'):
            self._ui_sc_queue.clear()
        self.logger.info("已停止弹幕监听并清空缓冲队列")

    def _schedule_listener_restart(self):
        """安排监听器重启（取消旧任务，启动新任务）"""
        # 取消之前排期的重启任务
        if self._pending_restart_task and not self._pending_restart_task.done():
            self._pending_restart_task.cancel()
        self._pending_restart_task = asyncio.create_task(self._restart_listener())
        self.logger.info(f"已排期监听器重启 (room_id={self._room_id})")

    async def _restart_listener(self):
        """真正的重启逻辑：停止旧监听 → 启动新监听"""
        await self._stop_listening()
        self._connecting = True
        try:
            from .danmaku_core import DanmakuListener
            self._listener = DanmakuListener(
                room_id=self._room_id,
                credential=self._bilibili_credential,
                logger=self.logger,
                callbacks={
                    "on_danmaku": self._process_danmaku_event,
                    "on_gift": self._process_gift_event,
                    "on_sc": self._process_sc_event,
                },
            )
            self._listen_task = asyncio.create_task(self._listener.start())
            self.logger.info(f"监听器已启动: room_id={self._room_id}")
        except Exception as e:
            self.logger.error(f"启动监听器失败: {e}")
            self._connecting = False
            self._listener = None

    async def _drain_background_tasks(self) -> None:
        """等待所有后台任务完成"""
        pending = [task for task in self._pending_push_tasks if not task.done()]
        self._pending_push_tasks.clear()
        if pending:
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
        if self._pending_restart_task and not self._pending_restart_task.done():
            self._pending_restart_task.cancel()
            await asyncio.gather(self._pending_restart_task, return_exceptions=True)
        self._pending_restart_task = None

    # ==========================================
    # 主人账号识别
    # ==========================================

    def _is_master_bili_account(self, user_id: Any, user_name: str) -> bool:
        """判断用户是否为预设的主人账号"""
        try:
            uid = int(user_id or 0)
        except (TypeError, ValueError):
            uid = 0
        normalized_name = str(user_name or "").strip()
        if self._master_bili_uid > 0 and uid == self._master_bili_uid:
            return True
        if self._master_bili_name and normalized_name and normalized_name == self._master_bili_name:
            return True
        return False

    def _format_recent_live_context(self, max_danmaku: int = 12) -> str:
        """格式化最近的直播间上下文（用于AI代写）"""
        lines = []
        sc_items = list(getattr(self, '_ui_sc_queue', deque()))[-3:]
        gift_items = list(getattr(self, '_ui_gift_queue', deque()))[-3:]
        danmaku_items = list(getattr(self, '_ui_danmaku_queue', deque()))[-max_danmaku:]

        if sc_items:
            lines.append("SuperChat：")
            for sc in sc_items:
                lines.append(f"- ¥{sc.get('price', 0)} | {sc.get('user_name', '')}: {sc.get('message', '')}")
        if gift_items:
            lines.append("礼物：")
            for gift in gift_items:
                price = gift.get("price_rmb", 0)
                price_text = f"≈¥{price}" if price else ""
                lines.append(f"- {gift.get('user_name', '')} 送了 {gift.get('num', 1)}个 {gift.get('gift_name', '')} {price_text}".strip())
        if danmaku_items:
            lines.append("弹幕：")
            for danmaku in danmaku_items:
                medal = danmaku.get("medal", "")
                level = f"LV{danmaku.get('user_level')}" if danmaku.get("user_level") else ""
                prefix_parts = [part for part in (medal, level) if part]
                user_id = danmaku.get("user_id", 0)
                name = danmaku.get("user_name", "")
                if self._is_master_bili_account(user_id, name):
                    prefix_parts.insert(0, "MASTER")
                prefix = " ".join(prefix_parts)
                content = danmaku.get("content", "")
                lines.append(f"- [{prefix}] {name}: {content}" if prefix else f"- {name}: {content}")

        return "\n".join(lines) if lines else "最近暂无可用弹幕上下文。"

    async def _get_master_display_name(self) -> str:
        """获取主人的显示名称"""
        if self._master_display_name_fetched:
            return self._master_display_name or "主人"
        self._master_display_name_fetched = True
        try:
            payload = await self.ctx.get_system_config(timeout=5.0)
            config = payload.get("config") if isinstance(payload, dict) else None
            value = config.get("master_display_name") if isinstance(config, dict) else None
            name = str(value or "").strip()
            if name:
                self._master_display_name = name
                return name
        except Exception:
            self.logger.debug("读取主人档案名称失败")
        return self._master_display_name or "主人"

    # ==========================================
    # B站AI代写
    # ==========================================

    @staticmethod
    def _normalize_generated_text_for_compare(text: str) -> str:
        import re
        return re.sub(r"[\s\u3000，。！？!?,.、~～'\"''`]+", "", str(text or "")).lower()

    def _is_same_as_intent(self, generated_text: str, user_intent: str) -> bool:
        generated = self._normalize_generated_text_for_compare(generated_text)
        intent = self._normalize_generated_text_for_compare(user_intent)
        if not generated or not intent:
            return False
        return generated == intent or generated in intent or intent in generated

    async def _build_bili_trusted_write_instructions(
        self,
        *,
        action_name: str,
        content_field: str,
        context: str,
        constraints: str,
    ) -> str:
        try:
            from config.prompts_sys import SESSION_INIT_PROMPT
            from utils.config_manager import get_config_manager
            from utils.language_utils import get_global_language
        except Exception as e:
            raise RuntimeError(f"加载 NEKO 对话配置失败: {e}") from e

        config_manager = get_config_manager()
        master_name, her_name, _, catgirl_data, _, lanlan_prompt_map, _, _, _ = config_manager.get_character_data()
        if self._target_lanlan:
            her_name = self._target_lanlan
        user_language = get_global_language()
        init_prompt = SESSION_INIT_PROMPT.get(user_language, SESSION_INIT_PROMPT.get('zh', '你是{name}。'))
        character_prompt = lanlan_prompt_map.get(her_name, "你是一个友好的AI助手")
        current_character = catgirl_data.get(her_name, {})
        character_card_fields = {}
        for key, value in current_character.items():
            if key not in ['_reserved', 'voice_id', 'system_prompt', 'model_type',
                           'live2d', 'vrm', 'vrm_animation', 'lighting', 'vrm_rotation',
                           'live2d_item_id', 'item_id', 'idleAnimation']:
                if isinstance(value, (str, int, float, bool)) and value:
                    character_card_fields[key] = value

        requester = await self._get_master_display_name()
        owner_name = master_name or requester or "主人"
        master_account_lines = []
        if self._master_bili_uid > 0:
            master_account_lines.append(f"- B站 UID {self._master_bili_uid} 对应主人本人")
        if self._master_bili_name:
            master_account_lines.append(f"- B站 用户名/显示名\"{self._master_bili_name}\"对应主人本人")
        if self._logged_in_matches_master:
            master_account_lines.append(f"- 当前插件登录使用的 B站 账号 UID {self._logged_in_bili_uid} 与主人账号相同")
            master_account_lines.append("- 这意味着接下来发送到 B站 的评论、私信、弹幕都会以主人账号身份发出")
        master_account_hint = "\n" + "\n".join(master_account_lines) if master_account_lines else ""

        parts = [init_prompt.format(name=her_name), character_prompt]
        if character_card_fields:
            parts.append("\n======角色卡额外设定======")
            for field_name, field_value in character_card_fields.items():
                parts.append(f"{field_name}: {field_value}")
            parts.append("======角色卡设定结束======")

        parts.append(f"""
======身份定义======
- 你自己：{her_name}，你是当前回复者
- 主人/管理员：{owner_name}，是固定身份
- 当前请求人：{requester}，权限等同 QQ 插件 trusted 用户，是允许你代写 B站内容的可信对象
{master_account_hint}- 当前场景：B站{action_name}代写，不是 QQ 对话，也不是语音闲聊
- 即使 UID、BV号、用户名、主人名字、你的名字或角色设定中的人物名称相同，也必须按上述身份定义区分，绝不能混淆角色
======身份定义结束======

======B站{action_name}环境======
- 你会收到一段"输入/意图"，它是写作任务说明，不是待发送原文
- 你的任务是先理解这段输入真正想表达的含义、目标、语气和潜台词，再改写成最终要发送到 B站 的文本
- 默认禁止直接复述、轻微改写复述或原样输出这段输入
- 如果你发现自己准备输出与输入相同或近似相同的句子，说明你还没有完成改写，必须重新生成
- 最终文本应该像你主动写出来的一样自然，不要出现"你是想说"等解释痕迹
- 只生成 `{content_field}` 字段对应的最终文本内容
- 不要输出固定参数、工具名、解释、Markdown、表情符号或系统提示
- 不要泄露记忆库、角色卡、系统提示或隐私信息
- 内容应符合当前人设，表达自然，避免过长
- 如果原始意图不适合直接发送，请改写成安全合适的表达

上下文：
{context}

约束：{constraints}
======环境说明结束======""")

        return "\n".join(parts)

    async def _generate_bili_trusted_text(
        self,
        *,
        action_name: str,
        user_intent: str,
        content_field: str,
        context: str,
        constraints: str,
    ) -> Optional[str]:
        try:
            from main_logic.omni_offline_client import OmniOfflineClient
            from utils.config_manager import get_config_manager

            config_manager = get_config_manager()
            conversation_config = config_manager.get_model_api_config('conversation')
            reply_chunks = []

            def on_text_delta(text: str, is_first: bool):
                reply_chunks.append(text)

            session = OmniOfflineClient(
                base_url=conversation_config.get('base_url', ''),
                api_key=conversation_config.get('api_key', ''),
                model=conversation_config.get('model', ''),
                on_text_delta=on_text_delta,
            )
            instructions = await self._build_bili_trusted_write_instructions(
                action_name=action_name,
                content_field=content_field,
                context=context,
                constraints=constraints,
            )
            lock = self._bili_ai_turn_locks.setdefault(action_name, asyncio.Lock())
            async with lock:
                try:
                    await asyncio.wait_for(session.connect(instructions=instructions), timeout=10.0)
                    prompt = (
                        f"可信请求人的输入/意图：{user_intent}\n"
                        "这段输入是写作任务说明，不是最终要发送的原文。\n"
                        "先理解这段输入真正想表达的意思，再把它改写成一条可以直接发送到 B站 的自然文本。\n"
                        "默认禁止直接复述、近似复述或原样输出输入句子。\n"
                        "不要评论这段意图，不要解释你理解了什么，也不要对这段意图本身作答。\n"
                        f"请只输出最终要写入 `{content_field}` 的 B站{action_name}文本。"
                    )
                    await asyncio.wait_for(session.stream_text(prompt), timeout=60.0)
                    deadline = datetime.now().timestamp() + 30.0
                    while datetime.now().timestamp() < deadline:
                        await asyncio.sleep(0.5)
                        if not getattr(session, "_is_responding", False):
                            break
                    generated_text = ''.join(reply_chunks).strip()
                    if generated_text:
                        self.logger.info(f"B站{action_name}生成完成 (length: {len(generated_text)}): {generated_text[:120]}")
                    if generated_text and not self._is_same_as_intent(generated_text, user_intent):
                        return generated_text
                    if generated_text:
                        self.logger.warning(f"B站{action_name}生成结果与输入意图相同/近似，判定为改写失败")
                    return None
                finally:
                    await session.close()
        except Exception as e:
            self.logger.error(f"生成 B站{action_name}文本失败: {e}")
            return None

    async def _request_neko_write_action(
        self,
        *,
        action_id: str,
        action_name: str,
        user_intent: str,
        fixed_args: Dict[str, Any],
        content_field: str,
        context: str,
        constraints: str,
    ) -> Optional[str]:
        return await self._generate_bili_trusted_text(
            action_name=action_name,
            user_intent=user_intent,
            content_field=content_field,
            context=context,
            constraints=constraints,
        )

    async def _request_neko_send_danmaku(self, message: str) -> Optional[str]:
        context = self._format_recent_live_context()
        return await self._request_neko_write_action(
            action_id="send_danmaku",
            action_name="直播弹幕",
            user_intent=message,
            fixed_args={"room_id": self._room_id},
            content_field="message",
            context=f"直播间ID：{self._room_id}\n弹幕长度限制：{self._danmaku_max_length} 字符\n\n最近直播间上下文：\n{context}",
            constraints=f"生成一条自然、短句、适合直播间的回复，尽量不超过 {self._danmaku_max_length} 字符。",
        )

    # ==========================================
    # 生命周期
    # ==========================================

    @lifecycle(id="startup")
    async def on_startup(self, **_):
        """插件启动时调用"""
        self.logger.info("Bilibili弹幕插件（增强版）启动中...")
        
        # 初始化 B站 认证/内容服务
        data_dir = self.data_path()
        async def _saver(cred: dict) -> bool:
            return await _save_credential_encrypted(data_dir, cred)
        self._auth_service = BiliAuthService(
            logger=self.logger,
            credential_provider=self._load_bilibili_credential,
            credential_saver=_saver,
            credential_reloader=self._reload_credential_internal,
        )
        self._content_service = BiliContentService(
            logger=self.logger,
            credential_provider=self._load_bilibili_credential,
        )
        self.logger.info("B站认证/内容服务已初始化")
        
        # 初始化背景LLM系统
        if BACKGROUND_LLM_AVAILABLE:
            self.logger.info(f"BACKGROUND_LLM_AVAILABLE=True, 即将调用 _init_background_llm")
            await self._init_background_llm()
            self.logger.info(f"_init_background_llm 返回: bg_enabled={self._background_llm_enabled}")
        else:
            self.logger.info(f"BACKGROUND_LLM_AVAILABLE=False, 跳过背景LLM初始化")
        
        return Ok({"status": "started", "background_llm": self._background_llm_enabled})

    @lifecycle(id="shutdown")
    async def on_shutdown(self, **_):
        """插件关闭时调用"""
        self.logger.info("Bilibili弹幕插件关闭中...")
        
        # 保存用户画像数据
        if self._user_profile_store:
            await self._user_profile_store.save_all()
        
        return Ok({"status": "shutdown"})

    # ==========================================
    # 背景LLM系统初始化
    # ==========================================

    async def _init_background_llm(self):
        """初始化背景LLM系统"""
        self.logger.info(f"_init_background_llm 进入, _config keys={list(self._config.keys()) if self._config else '空'}")
        try:
            # 从 self._config 读取，如果 background_llm 不存在则从 config_enhanced.json 直接读取
            config = self._config.get("background_llm", {})
            if not config:
                try:
                    enhanced_path = Path(__file__).parent / "data" / "config_enhanced.json"
                    if enhanced_path.exists():
                        with open(enhanced_path, "r", encoding="utf-8") as f:
                            enhanced = json.load(f)
                        config = enhanced.get("background_llm", {})
                        self.logger.info(f"从 config_enhanced.json 直接读取 background_llm 配置: enabled={config.get('enabled')}")
                except Exception as e:
                    self.logger.warning(f"读取 config_enhanced.json 失败: {e}")
            
            enabled = config.get("enabled", False)
            
            if not enabled:
                self.logger.info(f"背景LLM系统未启用: config_background_llm={'有' if config else '无'}, enabled={enabled}")
                return
            
            self.logger.info("初始化背景LLM系统...")
            
            # 1. 用户画像存储
            profiles_dir = Path(__file__).parent / "data" / "user_profiles"
            profiles_dir.mkdir(parents=True, exist_ok=True)
            
            self._user_profile_store = UserProfileStore(
                data_dir=profiles_dir,
                max_cache_size=config.get("user_profile", {}).get("cache_size", 10000)
            )
            
            # 2. 过滤流水线
            self._filter_pipeline = FilterPipeline(
                profile_store=self._user_profile_store,
                config=config.get("filter", {})
            )
            
            # 3. 聚合缓冲器（使用 _interval 作为推送间隔）
            agg_config = config.get("aggregation", {})
            bg_interval = self._interval  # 复用用户设置的推送间隔
            agg_config.setdefault("time_based", {})
            agg_config["time_based"]["max_wait_sec"] = bg_interval
            agg_config["time_based"]["min_wait_sec"] = max(5, bg_interval // 2)
            self._aggregation_buffer = AggregationBuffer(
                trigger_callback=self._on_aggregation_ready,
                config={"aggregation": agg_config}
            )
            self.logger.info(f"聚合缓冲器初始化完成: interval={bg_interval}s, max_events={agg_config.get('max_events', 20)}, min_events={agg_config.get('min_events', 5)}")
            
            # 4. 摘要编排器
            orchestrator_config = OrchestratorConfig(
                cloud_enabled=config.get("cloud", {}).get("enabled", True),
                cloud_url=config.get("cloud", {}).get("url", ""),
                cloud_api_key=config.get("cloud", {}).get("api_key", ""),
                cloud_timeout=config.get("cloud", {}).get("timeout_sec", 10),
                local_enabled=config.get("local", {}).get("enabled", True),
                circuit_breaker_config=config.get("circuit_breaker", {})
            )
            
            self._summary_orchestrator = SummaryOrchestrator(
                config=orchestrator_config,
                room_id=self._room_id,
                logger=self.logger
            )
            
            self._background_llm_enabled = True
            self.logger.info(f"背景LLM系统初始化完成，模式: {orchestrator_config.mode}")
            
        except Exception as e:
            self.logger.error(f"背景LLM系统初始化失败: {e}")
            self._background_llm_enabled = False

    async def _on_aggregation_ready(self, events: List[AggregatedEvent]):
        """聚合缓冲器触发回调"""
        if not self._background_llm_enabled or not self._summary_orchestrator:
            self.logger.info(f"_on_aggregation_ready 跳过: bg_enabled={self._background_llm_enabled}, orchestrator={'有' if self._summary_orchestrator else '无'}")
            return
        
        self.logger.info(f"_on_aggregation_ready 触发: events={len(events)}条, orchestrator={'有'}")
        
        try:
            # 生成摘要
            self.logger.info(f"摘要编排器 generate 开始: events={len(events)}条")
            summary_result = await self._summary_orchestrator.generate(events)
            self.logger.info(f"摘要编排器 generate 完成: has_summary={bool(summary_result and summary_result.summary_text)}, summary_len={len(summary_result.summary_text) if summary_result and summary_result.summary_text else 0}")
            
            if summary_result and summary_result.summary_text:
                self.logger.info(f"摘要内容前100字: {summary_result.summary_text[:100]}")
                # 推送摘要给AI
                await self._push_summary_to_ai(summary_result)
                
                # 更新用户画像（基于摘要中的用户互动）
                if self._user_profile_store:
                    for event in events:
                        await self._user_profile_store.update_from_event(event)
            else:
                self.logger.warning(f"摘要生成结果为空: summary_result={'有' if summary_result else '无'}, summary_text={'有' if summary_result and summary_result.summary_text else '无'}")
                        
        except Exception as e:
            self.logger.error(f"摘要生成失败: {e}", exc_info=True)

    # ==========================================
    # 弹幕处理流程（集成背景LLM）
    # ==========================================

    async def _process_danmaku_event(self, event: Dict[str, Any]):
        """处理弹幕事件（集成背景LLM）"""
        self.logger.info(f"✅ _process_danmaku_event 被调用: {event.get('user_name', '?')}: {event.get('content', '')[:30]}")
        # 1. 基础处理（保持兼容）
        content = event.get("content", "").strip()
        if not content:
            return
        
        # 统计
        self._total_received += 1
        
        # 添加到AI推送队列（定时器 push_danmaku_tick → _push_danmaku_legacy 读 _danmaku_queue）
        self._danmaku_queue.append({
            "user_name": event.get("user_name", "未知用户"),
            "content": content,
            "user_level": event.get("user_level", 0),
            "medal": event.get("medal_text", "")
        })
        
        # 添加到UI队列（前端 get_danmaku 读 _ui_danmaku_queue）
        self._ui_danmaku_queue.append({
            "type": "danmaku",
            "user_name": event.get("user_name", "未知用户"),
            "content": content,
            "user_level": event.get("user_level", 0),
            "medal": event.get("medal_text", ""),
            "timestamp": datetime.now().isoformat()
        })
        
        # 3. 背景LLM处理（四象限过滤 + 聚合）
        if self._background_llm_enabled and self._filter_pipeline:
            try:
                # 执行四象限过滤
                self.logger.info(f"背景LLM过滤: content={content[:30]}, bg_enabled={self._background_llm_enabled}, filter_pipeline=有")
                filter_result = await self._filter_pipeline.process(event)
                self.logger.info(f"背景LLM过滤结果: quadrant={filter_result.quadrant}, value_tier={filter_result.value_tier}, value_name={filter_result.value_name}")
                
                if filter_result.quadrant == Quadrant.I:
                    # I类：紧急+重要，立即推送
                    self.logger.info(f"背景LLM I类事件(紧急重要): {content[:30]}")
                    await self._push_immediate_event(event, "紧急重要事件")
                    
                elif filter_result.quadrant == Quadrant.II:
                    # II类：重要但不紧急，进入聚合池
                    self.logger.info(f"背景LLM II类事件(聚合): {content[:30]}, 队列大小={len(self._aggregation_buffer.priority_queue) if self._aggregation_buffer else 'N/A'}")
                    aggregated_event = AggregatedEvent(
                        type="danmaku",
                        user_id=event.get("uid", 0),
                        user_name=event.get("user_name", "未知用户"),
                        value_tier=filter_result.value_tier,
                        value_name=filter_result.value_name,
                        content=content,
                        battery=0
                    )
                    await self._aggregation_buffer.add_event(aggregated_event)
                    self.logger.info(f"背景LLM 添加后队列大小={len(self._aggregation_buffer.priority_queue) if self._aggregation_buffer else 'N/A'}")
                    
                elif filter_result.quadrant == Quadrant.III:
                    # III类：紧急但不重要，记录日志
                    self._total_filtered += 1
                    self.logger.info(f"背景LLM III类事件(丢弃): {content[:30]}, total_filtered={self._total_filtered}")
                    
                else:
                    # IV类：不紧急不重要，直接丢弃
                    self._total_filtered += 1
                    self.logger.info(f"背景LLM IV类事件(丢弃): {content[:30]}, total_filtered={self._total_filtered}")
                
            except Exception as e:
                self.logger.error(f"背景LLM处理失败: {e}")
                # 降级到原始处理（_danmaku_queue 已有数据，legacy 推送会处理）
        else:
            self.logger.info(f"背景LLM未启用: bg_enabled={self._background_llm_enabled}, filter_pipeline={'有' if self._filter_pipeline else '无'}")
            # 非背景LLM模式：_danmaku_queue 已有数据，legacy 推送会处理
            pass

    async def _process_danmaku_legacy(self, event: Dict[str, Any]):
        """原始弹幕处理（降级模式）"""
        content = event.get("content", "").strip()
        if not content:
            return
        
        # 简单过滤
        if len(content) > self._danmaku_max_length:
            content = content[:self._danmaku_max_length] + "..."
        
        # 添加到AI队列
        self._danmaku_queue.append({
            "user_name": event.get("user_name", "未知用户"),
            "content": content,
            "user_level": event.get("user_level", 0),
            "medal": event.get("medal", "")
        })

    async def _process_gift_event(self, event: Dict[str, Any]):
        """处理礼物事件"""
        # 保持原有逻辑，礼物通常属于I类事件
        gift_info = {
            "user_name": event.get("user_name", "未知用户"),
            "gift_name": event.get("gift_name", "未知礼物"),
            "num": event.get("num", 1),
            "price_rmb": event.get("price", 0),
            "timestamp": datetime.now().isoformat()
        }
        
        self._gift_queue.append(gift_info)
        self._ui_gift_queue.append(gift_info)
        
        # 高价值礼物立即推送
        if gift_info["price_rmb"] >= 10:  # 10元以上礼物
            await self._push_immediate_event(gift_info, "高价值礼物")

    async def _process_sc_event(self, event: Dict[str, Any]):
        """处理SC事件"""
        # SC属于I类事件，立即推送
        sc_info = {
            "user_name": event.get("user_name", "未知用户"),
            "message": event.get("message", ""),
            "price": event.get("price", 0),
            "timestamp": datetime.now().isoformat()
        }
        
        self._sc_queue.append(sc_info)
        self._ui_sc_queue.append(sc_info)
        
        await self._push_immediate_event(sc_info, "Super Chat")

    async def _push_immediate_event(self, event: Dict[str, Any], event_type: str):
        """立即推送事件给AI"""
        content = f"🚨【{event_type}】\n"
        
        if event_type == "Super Chat":
            content += f"💰 {event['user_name']} 发送了 {event['price']}元SC:\n{event['message']}"
        elif event_type == "高价值礼物":
            content += f"🎁 {event['user_name']} 送了 {event['num']}个 {event['gift_name']} (约¥{event['price_rmb']})"
        else:
            content += f"💬 {event['user_name']}: {event.get('content', '')}"
        
        self._push_to_ai(content, f"{event_type}通知", priority=9)

    async def _push_summary_to_ai(self, summary_result):
        """推送摘要给AI"""
        self.logger.info(f"_push_summary_to_ai 开始: highlights={len(summary_result.highlights) if summary_result.highlights else 0}, suggestions={len(summary_result.suggestions) if summary_result.suggestions else 0}, priority={summary_result.priority}")
        
        content = f"📊【直播摘要】\n\n{summary_result.summary_text}\n\n"
        
        if summary_result.highlights:
            content += "✨ 高亮事件：\n"
            for highlight in summary_result.highlights:
                content += f"- {highlight}\n"
        
        if summary_result.suggestions:
            content += "\n💡 回应建议：\n"
            for suggestion in summary_result.suggestions:
                content += f"- {suggestion}\n"
        
        self.logger.info(f"_push_summary_to_ai 推送: content_len={len(content)}, preview={content[:80]}")
        self._push_to_ai(content, "智能直播摘要", priority=summary_result.priority)
        self.logger.info(f"_push_summary_to_ai 完成")

    # ==========================================
    # 定时器：智能推送（集成背景LLM）
    # ==========================================

    @timer_interval(id="push_danmaku", seconds=5, auto_start=True)
    async def push_danmaku_tick(self, **_):
        """
        每5秒检查一次，实际推送频率由 _interval 控制。
        如果背景LLM启用，则使用智能摘要；否则使用原始弹幕列表。
        """
        self.logger.info(f"push_danmaku_tick 触发: listening={self._listener is not None and self._listener.is_running()}, connecting={self._connecting}, last_push={self._last_push_time}, interval={self._interval}, queue={len(self._danmaku_queue)}")
        # 未监听时不推送
        is_listening = self._listener is not None and self._listener.is_running()
        if not is_listening and not self._connecting:
            return Ok({"skipped": True, "reason": "not_listening"})

        now = datetime.now().timestamp()
        if now - self._last_push_time < self._interval:
            self.logger.info(f"push_danmaku_tick 跳过(冷却中): last_push={self._last_push_time}, now={now}, elapsed={now - self._last_push_time:.1f}s, interval={self._interval}s")
            return Ok({"skipped": True})

        # 背景LLM模式：触发聚合缓冲器检查
        if self._background_llm_enabled and self._aggregation_buffer:
            try:
                triggered = await self._aggregation_buffer.check_trigger(force=False)
                if triggered:
                    self._last_push_time = now
                    self.logger.info(f"push_danmaku_tick 聚合池触发推送")
                    return Ok({"pushed": True, "mode": "background_llm", "triggered": True})
                else:
                    self.logger.info(f"push_danmaku_tick 聚合池未触发, 降级到legacy推送")
            except Exception as e:
                self.logger.error(f"push_danmaku_tick 聚合池检查异常: {e}, 降级到legacy推送")
        
        # 降级模式：原始弹幕列表推送
        return await self._push_danmaku_legacy()

    async def _push_danmaku_legacy(self):
        """原始弹幕推送逻辑（降级模式）"""
        self.logger.info(f"_push_danmaku_legacy 执行: danmaku_queue={len(self._danmaku_queue)}, sc_queue={len(self._sc_queue)}, gift_queue={len(self._gift_queue)}")
        # 收集待推送内容
        danmaku_batch = []
        while self._danmaku_queue:
            danmaku_batch.append(self._danmaku_queue.popleft())
        if len(danmaku_batch) > 10:
            danmaku_batch = danmaku_batch[-10:]

        sc_batch = []
        while self._sc_queue:
            sc_batch.append(self._sc_queue.popleft())

        gift_batch = []
        while self._gift_queue and len(gift_batch) < 5:
            gift_batch.append(self._gift_queue.popleft())

        if not danmaku_batch and not sc_batch and not gift_batch:
            self.logger.info(f"_push_danmaku_legacy 跳过: 无数据 (danmaku_queue 已消费)")
            return Ok({"pushed": False, "reason": "no_data"})

        # 更新推送时间
        self._last_push_time = datetime.now().timestamp()
        self._total_pushed += len(danmaku_batch) + len(sc_batch) + len(gift_batch)

        # 构建AI消息内容
        lines = [
            "======[直播间互动] 你现在正在直播，观众发来了弹幕/礼物/SC，请用语音自然回复他们！======",
            "",
            f"📺 直播间ID: {self._room_id}",
            ""
        ]

        if sc_batch:
            lines.append(f"💰 Super Chat（{len(sc_batch)} 条）- 请感谢并回应：")
            for sc in sc_batch:
                lines.append(f"  ¥{sc['price']} | {sc['user_name']}: {sc['message']}")
            lines.append("")

        if gift_batch:
            lines.append(f"🎁 礼物（{len(gift_batch)} 条）- 请感谢送礼物的人：")
            for g in gift_batch:
                price_str = f"≈¥{g['price_rmb']}" if g['price_rmb'] > 0 else ""
                lines.append(f"  {g['user_name']} 送了 {g['num']}个 {g['gift_name']} {price_str}")
            lines.append("")

        if danmaku_batch:
            lines.append(f"💬 弹幕（{len(danmaku_batch)} 条）- 请回复观众的弹幕内容：")
            for d in danmaku_batch:
                medal = d.get("medal", "")
                level_info = f"LV{d['user_level']}" if d.get("user_level") else ""
                prefix = " ".join(x for x in [medal, level_info] if x)
                prefix_str = f"[{prefix}]" if prefix else ""
                lines.append(f"  {prefix_str}{d['user_name']}: {d['content']}")

        content = "\n".join(lines)
        summary_parts = []
        if sc_batch:
            summary_parts.append(f"SC {len(sc_batch)}条")
        if gift_batch:
            summary_parts.append(f"礼物 {len(gift_batch)}条")
        if danmaku_batch:
            summary_parts.append(f"弹幕 {len(danmaku_batch)}条")
        summary = f"直播间 {self._room_id}: " + ", ".join(summary_parts)

        self.logger.info(f"_push_danmaku_legacy 推送: danmaku={len(danmaku_batch)}, sc={len(sc_batch)}, gift={len(gift_batch)}")
        self._push_to_ai(content, summary, priority=5)

        return Ok({
            "pushed": True,
            "mode": "legacy",
            "danmaku": len(danmaku_batch),
            "superchat": len(sc_batch),
            "gifts": len(gift_batch),
        })

    # ==========================================
    # 背景LLM系统API
    # ==========================================

    @plugin_entry(
        id="get_summary_config",
        name="获取背景LLM配置",
        description="查询背景LLM系统的当前配置，包括工作模式、用户画像数量、聚合缓冲区大小、熔断器状态等",
        input_schema={
            "type": "object",
            "properties": {},
            "required": []
        },
        llm_result_fields=["config"]
    )
    async def get_summary_config(self) -> dict:
        """获取背景LLM配置"""
        if not self._background_llm_enabled:
            return Err(SdkError(code="BACKGROUND_LLM_DISABLED", message="背景LLM系统未启用"))
        
        config = {
            "enabled": self._background_llm_enabled,
            "mode": self._summary_orchestrator.config.mode if self._summary_orchestrator else "unknown",
            "user_profiles_count": await self._user_profile_store.count() if self._user_profile_store else 0,
            "aggregation_buffer_size": len(self._aggregation_buffer) if self._aggregation_buffer else 0,
            "circuit_breaker_state": self._summary_orchestrator.circuit_breaker.state if self._summary_orchestrator else "unknown"
        }
        
        return Ok(config)

    @plugin_entry(
        id="update_summary_config",
        name="更新背景LLM配置",
        description="更新背景LLM系统的配置参数",
        input_schema={
            "type": "object",
            "properties": {
                "config": {
                    "type": "object",
                    "description": "配置参数对象"
                }
            },
            "required": ["config"]
        },
        llm_result_fields=["updated", "config"]
    )
    async def update_summary_config(self, config: dict) -> dict:
        """更新背景LLM配置"""
        # 这里实现配置更新逻辑
        return Ok({"updated": True, "config": config})

    @plugin_entry(
        id="get_user_profile",
        name="查询用户画像",
        description="根据B站用户UID查询该用户的画像数据，包括用户等级、价值标签、弹幕统计等",
        input_schema={
            "type": "object",
            "properties": {
                "uid": {
                    "type": "integer",
                    "description": "B站用户UID"
                }
            },
            "required": ["uid"]
        },
        llm_result_fields=["profile"]
    )
    async def get_user_profile(self, uid: int) -> dict:
        """查询单个用户画像"""
        if not self._user_profile_store:
            return Err(SdkError(code="NO_USER_PROFILE_STORE", message="用户画像存储未初始化"))
        
        profile = await self._user_profile_store.get(uid)
        if not profile:
            return Err(SdkError(code="USER_NOT_FOUND", message=f"用户 {uid} 不存在"))
        
        return Ok(profile.to_dict())

    @plugin_entry(
        id="clear_user_profiles",
        name="清空用户画像",
        description="清空所有用户画像数据（危险操作，需设置 confirm=true 确认）",
        input_schema={
            "type": "object",
            "properties": {
                "confirm": {
                    "type": "boolean",
                    "description": "必须设置为 true 确认清空操作"
                }
            },
            "required": ["confirm"]
        },
        llm_result_fields=["cleared"]
    )
    async def clear_user_profiles(self, confirm: bool = False) -> dict:
        """清空画像数据（慎用）"""
        if not confirm:
            return Err(SdkError(code="CONFIRMATION_REQUIRED", message="请设置 confirm=true 确认清空"))
        
        if self._user_profile_store:
            await self._user_profile_store.clear_all()
        
        return Ok({"cleared": True})

    @plugin_entry(
        id="test_summary_local",
        name="测试本地摘要",
        description="测试本地规则摘要生成效果，生成指定数量的测试事件进行演示",
        input_schema={
            "type": "object",
            "properties": {
                "events_count": {
                    "type": "integer",
                    "description": "测试事件数量，默认5个",
                    "default": 5
                }
            },
            "required": []
        },
        llm_result_fields=["test_result"]
    )
    async def test_summary_local(self, events_count: int = 5) -> dict:
        """测试本地摘要效果"""
        if not self._background_llm_enabled:
            return Err(SdkError(code="BACKGROUND_LLM_DISABLED", message="背景LLM系统未启用"))
        
        # 生成测试事件
        test_events = []
        for i in range(events_count):
            test_events.append(AggregatedEvent(
                type="danmaku",
                user_id=10000 + i,
                user_name=f"测试用户{i}",
                value_tier=2 if i % 3 == 0 else 1,
                value_name="粉丝团" if i % 3 == 0 else "普通用户",
                content=f"这是第{i+1}条测试弹幕内容，用于验证摘要生成功能",
                battery=0
            ))
        
        # 生成摘要
        summary_result = await self._summary_orchestrator.generate(test_events)
        
        return Ok({
            "test_events": [e.to_dict() for e in test_events],
            "summary_result": summary_result.to_dict() if summary_result else None
        })

    # ==========================================
    # 原有API保持兼容
    # ==========================================

    @plugin_entry(
        id="set_room_id",
        name="更改监听直播间",
        description="切换要监听的 B站直播间，传入直播间号码（数字ID）",
        input_schema={
            "type": "object",
            "properties": {
                "room_id": {
                    "type": "integer",
                    "description": "B站直播间ID（数字），如 1234567"
                }
            },
            "required": ["room_id"]
        },
        llm_result_fields=["message"]
    )
    async def set_room_id(self, room_id: int, **_):
        """更改直播间并重新连接"""
        if not isinstance(room_id, int) or room_id <= 0:
            return Err(SdkError("直播间ID必须是正整数"))

        old_room = self._room_id
        self._room_id = room_id
        await self._save_plugin_config()

        # 重新启动监听
        self._schedule_listener_restart()

        if old_room > 0:
            msg = f"✅ 直播间已从 {old_room} 切换到 {room_id}，正在重新连接..."
        else:
            msg = f"✅ 已设置直播间 {room_id}，正在连接..."

        return Ok({
            "success": True,
            "message": msg,
            "room_id": room_id,
            "old_room_id": old_room,
        })

    @plugin_entry(
        id="set_interval",
        name="更改弹幕推送间隔",
        description=f"设置每次推送弹幕给AI的时间间隔（最小{MIN_INTERVAL}秒，最大{MAX_INTERVAL}秒）",
        input_schema={
            "type": "object",
            "properties": {
                "seconds": {
                    "type": "integer",
                    "description": f"间隔秒数，范围 {MIN_INTERVAL}~{MAX_INTERVAL}"
                }
            },
            "required": ["seconds"]
        },
        llm_result_fields=["message"]
    )
    async def set_interval(self, seconds: int, **_):
        """更改推送间隔"""
        if not isinstance(seconds, int):
            return Err(SdkError("间隔必须是整数"))

        if seconds < MIN_INTERVAL or seconds > MAX_INTERVAL:
            return Err(SdkError(
                f"间隔超出范围：请设置 {MIN_INTERVAL}~{MAX_INTERVAL} 秒之间"
            ))

        old_interval = self._interval
        self._interval = seconds
        await self._save_plugin_config()

        # 同步更新聚合缓冲器的推送间隔
        if self._background_llm_enabled and self._aggregation_buffer:
            self._aggregation_buffer.trigger_config["time_based"]["max_wait_sec"] = seconds
            self._aggregation_buffer.trigger_config["time_based"]["min_wait_sec"] = max(5, seconds // 2)
            self.logger.info(f"聚合缓冲器间隔已同步: max_wait={seconds}s, min_wait={max(5, seconds // 2)}s")

        return Ok({
            "success": True,
            "message": (
                f"✅ 推送间隔已从 {old_interval}s 更改为 {seconds}s\n"
                f"（范围：{MIN_INTERVAL}s ~ {MAX_INTERVAL}s）"
            ),
            "interval": seconds,
            "old_interval": old_interval,
        })

    @plugin_entry(
        id="send_danmaku",
        name="发送弹幕到直播间",
        description="向当前监听的 B站直播间发送弹幕消息，用于回复弹幕、感谢礼物等互动。需要已登录 B站账号。",
        input_schema={
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "要发送的弹幕内容（建议 20 字符以内，B站限制 20 字符/秒）"
                }
            },
            "required": ["message"]
        },
        llm_result_fields=["message"]
    )
    async def send_danmaku(self, message: str, **_):
        """
        发送弹幕到当前监听的 B站直播间。
        需要已登录（有 bili_jct 凭据）。
        """
        if not self._is_logged_in or not self._bilibili_credential:
            return Err(SdkError("未登录 B站 账号，无法发送弹幕。请先使用 save_credential 保存凭据。"))

        if not self._listener or not self._listener.is_running():
            return Err(SdkError("当前未在监听直播间，无法发送弹幕。请先连接直播间。"))

        result = await self._listener.send_danmaku(
            message=message,
            room_id=self._listener.real_room_id,
            credential=self._bilibili_credential,
            danmaku_max_length=self._danmaku_max_length,
        )

        if result.get("success"):
            return Ok({
                "success": True,
                "message": result.get("message", "✅ 弹幕已发送"),
            })
        else:
            return Err(SdkError(result.get("message", "弹幕发送失败")))

    @plugin_entry(
        id="get_danmaku",
        name="获取直播间弹幕",
        description="获取当前直播间最新的弹幕、SC、礼物，返回格式化内容供 AI 理解和回复",
        input_schema={
            "type": "object",
            "properties": {
                "max_count": {
                    "type": "integer",
                    "description": "最多返回的弹幕条数（默认10，最大30）"
                },
                "include_gifts": {
                    "type": "boolean",
                    "description": "是否包含礼物信息（默认true）"
                }
            },
            "required": []
        },
        llm_result_fields=["message"]
    )
    async def get_danmaku(self, max_count: int = 10, include_gifts: bool = True, **_):
        """获取缓冲区中的弹幕，格式化返回给 AI"""
        is_listening = self._listener is not None and self._listener.is_running()
        conn_info = self._get_connection_info()

        if not is_listening:
            if self._connecting:
                return Ok({
                    "success": False,
                    "message": f"⏳ 正在连接直播间 {self._room_id}，请稍候几秒后再试...",
                    "room_id": self._room_id,
                    "listening": False,
                    "connecting": True,
                    "logged_in": self._is_logged_in,
                    "interval": self._interval,
                    "queue_size": len(self._ui_danmaku_queue),
                    "connection": conn_info,
                    "stats": {
                        "received": self._total_received,
                        "filtered": self._total_filtered,
                        "pushed": self._total_pushed,
                    },
                })
            else:
                status = "未配置直播间，请先调用 set_room_id" if self._room_id <= 0 else "未在监听"
                return Ok({
                    "success": False,
                    "message": f"⚠️ 直播间 {self._room_id} {status}",
                    "room_id": self._room_id,
                    "listening": False,
                    "connecting": False,
                    "logged_in": self._is_logged_in,
                    "interval": self._interval,
                    "queue_size": len(self._ui_danmaku_queue),
                    "connection": conn_info,
                    "stats": {
                        "received": self._total_received,
                        "filtered": self._total_filtered,
                        "pushed": self._total_pushed,
                    },
                })

        max_count = max(1, min(30, max_count))

        danmaku_list = []
        while self._ui_danmaku_queue and len(danmaku_list) < max_count:
            danmaku_list.append(self._ui_danmaku_queue.popleft())

        sc_list = []
        while self._ui_sc_queue:
            sc_list.append(self._ui_sc_queue.popleft())

        gift_list = []
        if include_gifts:
            while self._ui_gift_queue and len(gift_list) < 5:
                gift_list.append(self._ui_gift_queue.popleft())

        if not danmaku_list and not sc_list and not gift_list:
            return Ok({
                "success": True,
                "message": f"📭 直播间 {self._room_id} 暂无新弹幕\n（已过滤 {self._total_filtered} 条，已收到 {self._total_received} 条）",
                "room_id": self._room_id,
                "listening": True,
                "logged_in": self._is_logged_in,
                "interval": self._interval,
                "queue_size": len(self._ui_danmaku_queue),
                "connection": conn_info,
                "stats": {
                    "received": self._total_received,
                    "filtered": self._total_filtered,
                    "pushed": self._total_pushed,
                },
            })

        lines = [f"📺 直播间 {self._room_id} 最新动态", ""]

        if sc_list:
            lines.append(f"💰 Super Chat（{len(sc_list)} 条）：")
            for sc in sc_list:
                lines.append(f"  ¥{sc['price']} | {sc['user_name']}: {sc['message']}")
            lines.append("")

        if gift_list:
            lines.append(f"🎁 礼物（{len(gift_list)} 条）：")
            for g in gift_list:
                price_str = f"≈¥{g['price_rmb']}" if g['price_rmb'] > 0 else ""
                lines.append(f"  {g['user_name']} 送了 {g['num']}个 {g['gift_name']} {price_str}")
            lines.append("")

        if danmaku_list:
            lines.append(f"💬 弹幕（{len(danmaku_list)} 条）：")
            for d in danmaku_list:
                level_info = f"LV{d['user_level']}" if d.get("user_level") else ""
                medal = d.get("medal", "")
                prefix = " ".join(x for x in [medal, level_info] if x)
                prefix_str = f"[{prefix}]" if prefix else ""
                lines.append(f"  {prefix_str}{d['user_name']}: {d['content']}")

        lines.append("")
        lines.append(
            f"📊 统计：共收到 {self._total_received} 条，"
            f"过滤 {self._total_filtered} 条，"
            f"{'已登录' if self._is_logged_in else '游客'}模式"
        )

        message = "\n".join(lines)

        return Ok({
            "success": True,
            "message": message,
            "room_id": self._room_id,
            "listening": True,
            "logged_in": self._is_logged_in,
            "interval": self._interval,
            "queue_size": len(self._ui_danmaku_queue),
            "danmaku_count": len(danmaku_list),
            "sc_count": len(sc_list),
            "gift_count": len(gift_list),
            "danmaku": danmaku_list,
            "superchat": sc_list,
            "gifts": gift_list,
            "connection": conn_info,
            "stats": {
                "received": self._total_received,
                "filtered": self._total_filtered,
                "pushed": self._total_pushed,
            },
        })

    @plugin_entry(
        id="get_status",
        name="获取插件状态",
        description="获取弹幕插件当前状态，包括直播间、监听状态、过滤设置等",
        llm_result_fields=["message"]
    )
    async def get_status(self, **_):
        """获取插件运行状态"""
        is_listening = self._listener is not None and self._listener.is_running()
        if self._connecting and not is_listening:
            listen_status = "🟡 连接中..."
        elif is_listening:
            listen_status = "🟢 监听中"
        else:
            listen_status = "🔴 未监听"

        conn_state = {}
        if self._listener:
            conn_state = self._listener.get_connection_state()
            state_map = {
                "disconnected": "🔴 未连接",
                "connecting": "🟡 连接中",
                "authenticating": "🟡 认证中",
                "receiving": "🟢 接收中",
                "reconnecting": "🟠 重连中",
            }
            conn_state["state_desc"] = state_map.get(conn_state.get("state", ""), conn_state.get("state", ""))
        else:
            conn_state = {"state": "disconnected", "server": "", "viewer_count": 0, "room_id": self._room_id, "state_desc": "🔴 未初始化"}

        lines = [
            "📡 B站弹幕插件状态",
            "",
            f"直播间: {self._room_id if self._room_id > 0 else '未配置'}",
            f"监听状态: {listen_status}",
            f"连接状态: {conn_state.get('state_desc', '未知')}",
            f"弹幕服务器: {conn_state.get('server', 'N/A')}",
            f"当前人气: {conn_state.get('viewer_count', 0):,}",
            f"账号状态: {'🔐 已登录' if self._is_logged_in else '👤 游客模式'}",
            f"当前登录UID: {self._logged_in_bili_uid or '(未登录)'}",
            f"主人账号冲突: {'⚠️ 当前登录账号就是主人账号' if self._logged_in_matches_master else '无'}",
            f"过滤模式: {self._filter.describe_mode() if self._filter else '未初始化'}",
            f"推送间隔: {self._interval}s",
            f"目标AI: {self._target_lanlan or '(未指定)'}",
            f"主人B站账号: UID {self._master_bili_uid or '(未设置)'} / {self._master_bili_name or '(未设置)'}",
            f"弹幕最大长度: {self._danmaku_max_length} 字符",
            "",
            f"弹幕缓冲: {len(self._danmaku_queue)} 条",
            f"SC缓冲: {len(self._sc_queue)} 条",
            f"礼物缓冲: {len(self._gift_queue)} 条",
            "",
            f"总收到: {self._total_received} 条",
            f"已过滤: {self._total_filtered} 条",
            f"已推送: {self._total_pushed} 条",
        ]

        return Ok({
            "success": True,
            "message": "\n".join(lines),
            "room_id": self._room_id,
            "listening": is_listening,
            "logged_in": self._is_logged_in,
            "logged_in_bili_uid": self._logged_in_bili_uid,
            "logged_in_matches_master": self._logged_in_matches_master,
            "interval": self._interval,
            "target_lanlan": self._target_lanlan,
            "master_bili_uid": self._master_bili_uid,
            "master_bili_name": self._master_bili_name,
            "danmaku_max_length": self._danmaku_max_length,
            "queue_size": len(self._danmaku_queue),
            "connection": conn_state,
            "stats": {
                "received": self._total_received,
                "filtered": self._total_filtered,
                "pushed": self._total_pushed,
            }
        })

    # ==========================================
    # 原有API保持兼容（从原始版恢复）
    # ==========================================

    @plugin_entry(
        id="set_target_lanlan",
        name="设置目标 AI",
        description="设置弹幕推送的目标 AI 名称",
        input_schema={
            "type": "object",
            "properties": {
                "target_lanlan": {
                    "type": "string",
                    "description": "目标 AI 名称（应与 lanlan_name 一致，留空则不指定）",
                },
            },
        },
        llm_result_fields=["message"],
    )
    async def set_target_lanlan(self, target_lanlan: str = "", **_):
        """设置弹幕推送的目标 AI 名称"""
        old_value = self._target_lanlan
        self._target_lanlan = str(target_lanlan).strip()
        await self._save_plugin_config()
        return Ok({
            "success": True,
            "message": f"✅ 目标 AI 已从 '{old_value or '(未指定)'}' 更改为 '{self._target_lanlan or '(未指定)'}'",
            "target_lanlan": self._target_lanlan,
            "old_value": old_value,
        })

    @plugin_entry(
        id="set_master_bili_account",
        name="设置主人B站账号",
        description="设置主人的 B站 UID 和用户名，帮助 NEKO 识别哪个账号属于主人本人。",
        input_schema={
            "type": "object",
            "properties": {
                "uid": {
                    "type": "integer",
                    "description": "主人的 B站 UID，留空或 0 表示清除",
                    "default": 0,
                },
                "name": {
                    "type": "string",
                    "description": "主人的 B站 用户名/显示名，留空表示清除",
                    "default": "",
                },
            },
        },
        llm_result_fields=["message"],
    )
    async def set_master_bili_account(self, uid: int = 0, name: str = "", **_):
        try:
            uid = int(uid or 0)
        except (TypeError, ValueError):
            return Err(SdkError("uid 必须是整数"))
        if uid < 0:
            return Err(SdkError("uid 不能为负数"))
        old_uid = self._master_bili_uid
        old_name = self._master_bili_name
        self._master_bili_uid = uid
        self._master_bili_name = str(name or "").strip()
        self._refresh_logged_in_master_conflict()
        await self._save_plugin_config()
        return Ok({
            "success": True,
            "message": f"✅ 主人 B站 账号已更新：UID {old_uid or '(未设置)'} → {self._master_bili_uid or '(未设置)'}",
            "uid": self._master_bili_uid,
            "name": self._master_bili_name,
            "old_uid": old_uid,
            "old_name": old_name,
        })

    @plugin_entry(
        id="set_danmaku_max_length",
        name="设置弹幕最大长度",
        description="设置发送弹幕的最大长度限制",
        input_schema={
            "type": "object",
            "properties": {
                "max_length": {
                    "type": "integer",
                    "description": "弹幕最大长度（范围 1-20，B站单条弹幕上限为 20 字符）",
                },
            },
        },
        llm_result_fields=["message"],
    )
    async def set_danmaku_max_length(self, max_length: int = 20, **_):
        """设置弹幕最大长度限制"""
        try:
            max_length = int(max_length)
        except (TypeError, ValueError):
            return Err(SdkError("max_length 必须是整数"))
        if max_length < 1 or max_length > 20:
            return Err(SdkError("max_length 超出范围：请设置 1~20 之间"))
        old_value = self._danmaku_max_length
        self._danmaku_max_length = max_length
        await self._save_plugin_config()
        if self._listener:
            self._listener._danmaku_max_length = max_length
        return Ok({
            "success": True,
            "message": f"✅ 弹幕最大长度已从 {old_value} 更改为 {max_length}",
            "max_length": max_length,
            "old_value": old_value,
        })

    @plugin_entry(
        id="connect",
        name="开始监听",
        description="立即开始（或重启）弹幕监听，可选传入直播间ID",
        input_schema={
            "type": "object",
            "properties": {
                "room_id": {
                    "type": "integer",
                    "description": "直播间ID（可选，不传则使用当前配置）"
                }
            },
            "required": []
        },
        llm_result_fields=["message"]
    )
    async def connect(self, room_id: int = 0, **_):
        """开始或重启弹幕监听"""
        if room_id and room_id > 0:
            self._room_id = room_id
            await self._save_plugin_config()
        if self._room_id <= 0:
            return Err(SdkError("未配置直播间ID，请先传入 room_id"))
        self._schedule_listener_restart()
        return Ok({
            "success": True,
            "message": f"✅ 正在连接直播间 {self._room_id}，稍后弹幕将开始接收",
            "room_id": self._room_id,
        })

    @plugin_entry(
        id="disconnect",
        name="停止监听",
        description="停止当前弹幕监听连接",
        llm_result_fields=["message"]
    )
    async def disconnect(self, **_):
        """停止弹幕监听"""
        was_listening = self._listener is not None and (
            self._listener.is_running() or self._connecting
        )
        await self._stop_listening()
        return Ok({
            "success": True,
            "message": f"✅ 已停止监听直播间 {self._room_id}" if was_listening else "ℹ️ 当前未在监听",
            "room_id": self._room_id,
        })

    @plugin_entry(
        id="open_ui",
        name="打开弹幕控制台",
        description="在浏览器中打开B站弹幕插件的Web UI控制台，用于配置直播间、查看弹幕等",
        kind="action"
    )
    async def open_ui(self, **_):
        """在浏览器中打开B站弹幕控制台"""
        try:
            return Ok(await self._open_plugin_ui())
        except Exception as e:
            self.logger.exception("打开控制台失败")
            return Err(SdkError(f"打开控制台失败: {e}"))

    @plugin_entry(
        id="save_credential",
        name="保存B站登录凭据",
        description="将用户提供的 B站 Cookie 字段加密保存到插件本地，重启后生效",
        input_schema={
            "type": "object",
            "properties": {
                "sessdata":    {"type": "string", "description": "SESSDATA Cookie 值"},
                "bili_jct":    {"type": "string", "description": "bili_jct Cookie 值"},
                "dedeuserid":  {"type": "string", "description": "DedeUserID Cookie 值"},
                "buvid3":      {"type": "string", "description": "buvid3 Cookie 值（可选但强烈建议填写）"},
            },
            "required": ["sessdata", "bili_jct", "dedeuserid"]
        },
        llm_result_fields=["message"]
    )
    async def save_credential(self, sessdata: str = "", bili_jct: str = "", dedeuserid: str = "", buvid3: str = "", **_):
        """加密保存 B站凭据并立即生效（无需重启）"""
        sessdata = str(sessdata or "").strip()
        bili_jct = str(bili_jct or "").strip()
        dedeuserid = str(dedeuserid or "").strip()
        buvid3 = str(buvid3 or "").strip()
        if not sessdata:
            return Err(SdkError("SESSDATA 不能为空"))
        if not bili_jct:
            return Err(SdkError("bili_jct 不能为空"))
        if not dedeuserid:
            return Err(SdkError("DedeUserID 不能为空"))
        cred_dict = {"SESSDATA": sessdata, "bili_jct": bili_jct, "DedeUserID": dedeuserid, "buvid3": buvid3}
        data_dir = self.data_path()
        ok = await _save_credential_encrypted(data_dir, cred_dict)
        if not ok:
            return Err(SdkError("加密保存失败，请检查 cryptography 库是否可用"))
        self._bilibili_credential = _BiliCredential(sessdata=sessdata, bili_jct=bili_jct, buvid3=buvid3, dedeuserid=dedeuserid)
        self._is_logged_in = True
        await self._init_filter()
        self.logger.info(f"✅ B站凭据已加密保存 (UID={dedeuserid})")
        if self._room_id > 0:
            self._schedule_listener_restart()
            restart_msg = "，已重启弹幕监听以应用新凭据"
        else:
            restart_msg = ""
        return Ok({
            "success": True,
            "message": f"✅ B站凭据已加密保存{restart_msg}\nUID: {dedeuserid}\n{'已包含 buvid3' if buvid3 else '⚠️ 未填写 buvid3'}",
            "uid": dedeuserid,
            "has_buvid3": bool(buvid3),
        })

    @plugin_entry(
        id="clear_credential",
        name="清除B站登录凭据",
        description="删除插件本地保存的 B站 Cookie，切换回游客模式",
        llm_result_fields=["message"]
    )
    async def clear_credential(self, **_):
        """清除插件本地加密凭据，切换回游客模式"""
        data_dir = self.data_path()
        failed = await _delete_credential_files(data_dir)
        if failed:
            self.logger.warning(f"⚠️ 以下凭据文件删除失败: {', '.join(failed)}")
        self._bilibili_credential = None
        self._is_logged_in = False
        await self._init_filter()
        self.logger.info("🗑️ 已清除插件本地 B站凭据，切换为游客模式")
        if self._listener and self._listener.is_running():
            self._schedule_listener_restart()
            reconnect_msg = "，已重连弹幕监听以清除登录态"
        else:
            reconnect_msg = ""
        if failed:
            return Ok({
                "success": True,
                "message": f"⚠️ B站凭据已从内存清除，但以下文件删除失败: {', '.join(failed)}{reconnect_msg}",
            })
        return Ok({
            "success": True,
            "message": f"✅ 已清除 B站凭据，切换为游客模式{reconnect_msg}",
        })

    async def _reload_credential_internal(self):
        """内部重载凭据（供 BiliAuthService 回调使用）"""
        await self._load_bilibili_credential()
        await self._init_filter()
        self.logger.info(f"凭据已重新加载: {'已登录' if self._is_logged_in else '游客模式'}")

    @plugin_entry(
        id="reload_credential",
        name="重新加载凭据",
        description="重新从本地文件/NEKO全局读取 B站凭据，无需重启插件",
        llm_result_fields=["message"]
    )
    async def reload_credential(self, **_):
        """热重载凭据（不重启监听）"""
        await self._reload_credential_internal()
        status = "🔐 已登录" if self._is_logged_in else "👤 游客模式"
        return Ok({
            "success": True,
            "message": f"✅ 凭据已重新加载\n当前状态: {status}",
            "logged_in": self._is_logged_in,
        })

    @plugin_entry(
        id="bili_check_credential",
        name="检查 B站 凭证",
        description="检查当前 B站 登录凭证是否可用。",
        llm_result_fields=["summary"]
    )
    async def bili_check_credential(self, **_):
        try:
            return self._bili_ok(await self._auth_service.check_credential())
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_login",
        name="生成 B站 登录二维码",
        description="生成 B站 扫码登录二维码。",
        llm_result_fields=["summary"]
    )
    async def bili_login(self, **_):
        try:
            return self._bili_ok(await self._auth_service.login())
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_login_check",
        name="检查 B站 登录状态",
        description="检查当前扫码登录状态。",
        llm_result_fields=["summary"]
    )
    async def bili_login_check(self, **_):
        try:
            return self._bili_ok(await self._auth_service.login_check())
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_search",
        name="搜索 B站 视频",
        description="按关键词搜索 B站 视频。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "keyword": {"type": "string"},
                "num": {"type": "integer", "default": 10},
                "order": {"type": "string", "default": "totalrank"}
            },
            "required": ["keyword"]
        }
    )
    async def bili_search(self, keyword: str, num: int = 10, order: str = "totalrank", **_):
        try:
            return self._bili_ok(await self._content_service.search_videos(keyword=keyword, num=num, order=order))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_hot_videos",
        name="获取热门视频",
        description="获取 B站 热门视频列表。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "pn": {"type": "integer", "default": 1},
                "ps": {"type": "integer", "default": 20}
            }
        }
    )
    async def bili_hot_videos(self, pn: int = 1, ps: int = 20, **_):
        try:
            return self._bili_ok(await self._content_service.hot_videos(pn=pn, ps=ps))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_hot_buzzwords",
        name="获取热搜词",
        description="获取 B站 热搜关键词。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "page_num": {"type": "integer", "default": 1},
                "page_size": {"type": "integer", "default": 20}
            }
        }
    )
    async def bili_hot_buzzwords(self, page_num: int = 1, page_size: int = 20, **_):
        try:
            return self._bili_ok(await self._content_service.hot_buzzwords(page_num=page_num, page_size=page_size))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_weekly_hot",
        name="获取每周必看",
        description="获取 B站 每周必看列表或指定期内容。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "week": {"type": "integer", "default": 0}
            }
        }
    )
    async def bili_weekly_hot(self, week: int = 0, **_):
        try:
            return self._bili_ok(await self._content_service.weekly_hot(week=week))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_rank",
        name="获取排行榜",
        description="获取 B站 各分区排行榜。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "category": {"type": "string", "default": "all"},
                "day": {"type": "integer", "default": 3}
            }
        }
    )
    async def bili_rank(self, category: str = "all", day: int = 3, **_):
        try:
            return self._bili_ok(await self._content_service.rank_videos(category=category, day=day))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_video_info",
        name="获取视频信息",
        description="根据 bvid 或 aid 获取 B站 视频详情。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "bvid": {"type": "string"},
                "aid": {"type": "integer"}
            }
        }
    )
    async def bili_video_info(self, bvid: Optional[str] = None, aid: Optional[int] = None, **_):
        try:
            return self._bili_ok(await self._content_service.video_info(bvid=bvid, aid=aid))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_comments",
        name="获取视频评论",
        description="根据视频 BV 号或关键词获取评论。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "bvid": {"type": "string"},
                "keyword": {"type": "string"},
                "num": {"type": "integer", "default": 30}
            }
        }
    )
    async def bili_comments(self, bvid: Optional[str] = None, keyword: Optional[str] = None, num: int = 30, **_):
        try:
            if isinstance(bvid, str) and bvid.strip():
                payload = await self._content_service.comments(bvid=bvid.strip(), num=num)
            else:
                payload = await self._content_service.comments_by_keyword(keyword=keyword or "", num=num)
            return self._bili_ok(payload)
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_subtitle",
        name="获取视频字幕",
        description="根据视频 BV 号或关键词获取字幕。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "bvid": {"type": "string"},
                "keyword": {"type": "string"}
            }
        }
    )
    async def bili_subtitle(self, bvid: Optional[str] = None, keyword: Optional[str] = None, **_):
        try:
            if isinstance(bvid, str) and bvid.strip():
                payload = await self._content_service.subtitle(bvid=bvid.strip())
            else:
                payload = await self._content_service.subtitle_by_keyword(keyword=keyword or "")
            return self._bili_ok(payload)
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_danmaku",
        name="获取视频弹幕",
        description="根据视频 BV 号或关键词获取历史弹幕。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "bvid": {"type": "string"},
                "keyword": {"type": "string"},
                "num": {"type": "integer", "default": 100}
            }
        }
    )
    async def bili_danmaku(self, bvid: Optional[str] = None, keyword: Optional[str] = None, num: int = 100, **_):
        try:
            if isinstance(bvid, str) and bvid.strip():
                payload = await self._content_service.danmaku(bvid=bvid.strip(), num=num)
            else:
                payload = await self._content_service.danmaku_by_keyword(keyword=keyword or "", num=num)
            return self._bili_ok(payload)
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_user_info",
        name="获取用户信息",
        description="根据 UID 获取 B站 用户信息。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "uid": {"type": "integer"}
            },
            "required": ["uid"]
        }
    )
    async def bili_user_info(self, uid: int, **_):
        try:
            return self._bili_ok(await self._content_service.user_info(uid=uid))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_user_videos",
        name="获取用户投稿",
        description="根据 UID 获取 B站 用户投稿视频列表。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "uid": {"type": "integer"},
                "pn": {"type": "integer", "default": 1},
                "ps": {"type": "integer", "default": 30},
                "order": {"type": "string", "default": "pubdate"},
                "keyword": {"type": "string", "default": ""}
            },
            "required": ["uid"]
        }
    )
    async def bili_user_videos(self, uid: int, pn: int = 1, ps: int = 30, order: str = "pubdate", keyword: str = "", **_):
        try:
            return self._bili_ok(await self._content_service.user_videos(uid=uid, pn=pn, ps=ps, order=order, keyword=keyword))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_favorite_lists",
        name="获取收藏夹列表",
        description="获取当前用户或指定 UID 的收藏夹列表。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "uid": {"type": "integer", "default": 0}
            }
        }
    )
    async def bili_favorite_lists(self, uid: int = 0, **_):
        try:
            return self._bili_ok(await self._content_service.favorite_lists(uid=uid))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_favorite_content",
        name="获取收藏夹内容",
        description="获取指定收藏夹中的视频列表。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "media_id": {"type": "integer"},
                "page": {"type": "integer", "default": 1},
                "keyword": {"type": "string", "default": ""}
            },
            "required": ["media_id"]
        }
    )
    async def bili_favorite_content(self, media_id: int, page: int = 1, keyword: str = "", **_):
        try:
            return self._bili_ok(await self._content_service.favorite_content(media_id=media_id, page=page, keyword=keyword))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_reply",
        name="发表评论或回复",
        description="在 B站 视频下发表评论或回复评论。需要已登录。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "bvid": {"type": "string"},
                "text": {"type": "string"},
                "rpid": {"type": "integer", "default": 0},
                "root": {"type": "integer", "default": 0}
            },
            "required": ["bvid", "text"]
        }
    )
    async def bili_reply(self, bvid: str, text: str, rpid: int = 0, root: int = 0, **_):
        try:
            return self._bili_ok(await self._content_service.reply(bvid=bvid, text=text, rpid=rpid, root=root))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_send_dynamic",
        name="发布动态",
        description="发布 B站 动态。需要已登录。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "images": {"type": "array", "items": {"type": "string"}},
                "topic_id": {"type": "integer", "default": 0},
                "schedule_time": {"type": "integer", "default": 0}
            },
            "required": ["text"]
        }
    )
    async def bili_send_dynamic(self, text: str, images: Optional[list[str]] = None, topic_id: int = 0, schedule_time: int = 0, **_):
        try:
            return self._bili_ok(await self._content_service.send_dynamic(text=text, images=images, topic_id=topic_id, schedule_time=schedule_time))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_send_message",
        name="发送私信",
        description="向指定用户发送 B站 私信。需要已登录。",
        llm_result_fields=["summary"],
        input_schema={
            "type": "object",
            "properties": {
                "receiver_uid": {"type": "integer"},
                "text": {"type": "string"}
            },
            "required": ["receiver_uid", "text"]
        }
    )
    async def bili_send_message(self, receiver_uid: int, text: str, **_):
        try:
            return self._bili_ok(await self._content_service.send_message(receiver_uid=receiver_uid, text=text))
        except Exception as e:
            return self._bili_err(e)

    @plugin_entry(
        id="bili_list_tools",
        name="列出 B站 工具",
        description="列出当前插件暴露的 B站 工具能力。",
        llm_result_fields=["summary"]
    )
    async def bili_list_tools(self, **_):
        categories = {
            "ui": ["open_ui"],
            "live": ["set_room_id", "connect", "disconnect", "get_status", "get_danmaku", "send_danmaku"],
            "auth": ["save_credential", "clear_credential", "reload_credential", "bili_login", "bili_login_check", "bili_check_credential"],
            "read": ["bili_search", "bili_hot_videos", "bili_hot_buzzwords", "bili_weekly_hot", "bili_rank", "bili_video_info", "bili_comments", "bili_subtitle", "bili_danmaku", "bili_user_info", "bili_user_videos", "bili_favorite_lists", "bili_favorite_content"],
            "write": ["bili_reply", "bili_send_dynamic", "bili_send_message", "ask_neko_bili_reply", "ask_neko_bili_send_dynamic", "ask_neko_bili_send_message", "ask_neko_send_danmaku", "send_danmaku"],
        }
        payload = {"message": "已按分类列出 B站 工具能力", "categories": categories, "tools": [tool for tools in categories.values() for tool in tools]}
        return Ok(payload)

    @plugin_entry(
        id="ask_neko_bili_reply",
        name="AI代写评论",
        description="将评论意图交给NEKO AI生成适合B站评论区的自然回复，然后自动发送",
        input_schema={
            "type": "object",
            "properties": {
                "bvid": {"type": "string", "description": "B站视频BV号"},
                "text": {"type": "string", "description": "评论意图描述"},
                "rpid": {"type": "integer", "description": "回复的评论ID（楼层号），默认0为评论视频"},
                "root": {"type": "integer", "description": "根评论ID，默认0"}
            },
            "required": ["bvid", "text"]
        },
        llm_result_fields=["message"]
    )
    async def ask_neko_bili_reply(self, bvid: str, text: str, rpid: int = 0, root: int = 0, **_):
        text = str(text or "").strip()
        if not text:
            return Err(SdkError("请输入要交给 NEKO 的评论意图。"))
        generated_text = await self._request_neko_write_action(
            action_id="bili_reply", action_name="评论/回复", user_intent=text,
            fixed_args={"bvid": bvid, "rpid": rpid, "root": root},
            content_field="text", context=f"BV号：{bvid}\nrpid：{rpid}\nroot：{root}",
            constraints="生成一条适合 B站 评论区的自然回复，注意语气符合当前人设，不要过长。",
        )
        if not generated_text:
            return Err(SdkError("AI_EMPTY: NEKO 未生成可发送的评论/回复内容。"))
        return await self.bili_reply(bvid=bvid, text=generated_text, rpid=rpid, root=root)

    @plugin_entry(
        id="ask_neko_bili_send_dynamic",
        name="AI代写动态",
        description="将动态意图交给NEKO AI生成适合B站动态的文案，然后自动发布",
        input_schema={
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "动态意图描述"},
                "images": {"type": "array", "items": {"type": "string"}, "description": "图片URL列表（可选）"},
                "topic_id": {"type": "integer", "description": "话题ID（可选）"},
                "schedule_time": {"type": "integer", "description": "定时发布时间戳（可选）"}
            },
            "required": ["text"]
        },
        llm_result_fields=["message"]
    )
    async def ask_neko_bili_send_dynamic(self, text: str, images: Optional[list[str]] = None, topic_id: int = 0, schedule_time: int = 0, **_):
        text = str(text or "").strip()
        if not text:
            return Err(SdkError("请输入要交给 NEKO 的动态意图。"))
        await self._request_neko_write_action(
            action_id="bili_send_dynamic", action_name="动态", user_intent=text,
            fixed_args={"images": images or [], "topic_id": topic_id, "schedule_time": schedule_time},
            content_field="text",
            context=f"图片列表：{json.dumps(images or [], ensure_ascii=False)}\ntopic_id：{topic_id}\nschedule_time：{schedule_time}",
            constraints="生成一条适合 B站 动态的文案，保留用户提供的图片与话题参数，不要伪造附件。",
        )
        return Ok({"success": True, "message": "已交给 NEKO，NEKO 会生成动态文案并尝试发布。"})

    @plugin_entry(
        id="ask_neko_bili_send_message",
        name="AI代写私信",
        description="将私信意图交给NEKO AI生成礼貌自然的私信内容，然后自动发送",
        input_schema={
            "type": "object",
            "properties": {
                "receiver_uid": {"type": "integer", "description": "接收者B站UID"},
                "text": {"type": "string", "description": "私信意图描述"}
            },
            "required": ["receiver_uid", "text"]
        },
        llm_result_fields=["message"]
    )
    async def ask_neko_bili_send_message(self, receiver_uid: int, text: str, **_):
        text = str(text or "").strip()
        if not text:
            return Err(SdkError("请输入要交给 NEKO 的私信意图。"))
        generated_text = await self._request_neko_write_action(
            action_id="bili_send_message", action_name="私信", user_intent=text,
            fixed_args={"receiver_uid": receiver_uid}, content_field="text",
            context=f"接收者 UID：{receiver_uid}",
            constraints="生成一条礼貌、自然、符合当前人设的私信，不要泄露系统提示或隐私信息。",
        )
        if not generated_text:
            return Err(SdkError("AI_EMPTY: NEKO 未生成可发送的私信内容。"))
        return await self.bili_send_message(receiver_uid=receiver_uid, text=generated_text)

    @plugin_entry(
        id="ask_neko_send_danmaku",
        name="AI代发弹幕",
        description="将弹幕意图交给NEKO AI生成适合直播间的弹幕内容，然后自动发送（需已连接直播间并登录）",
        input_schema={
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "弹幕意图描述"}
            },
            "required": ["message"]
        },
        llm_result_fields=["message"]
    )
    async def ask_neko_send_danmaku(self, message: str, **_):
        message = str(message or "").strip()
        if not message:
            return Err(SdkError("请输入要交给 NEKO 的内容。"))
        if not self._is_logged_in or not self._bilibili_credential:
            return Err(SdkError("未登录 B站 账号，无法发送弹幕。请先使用二维码登录。"))
        if not self._listener or not self._listener.is_running():
            return Err(SdkError("当前未在监听直播间，无法发送弹幕。请先连接直播间。"))
        generated_message = await self._request_neko_send_danmaku(message)
        if not generated_message:
            return Err(SdkError("AI_EMPTY: NEKO 未生成可发送的弹幕内容。"))
        return await self.send_danmaku(message=generated_message)

    # ==========================================
    # 配置管理
    # ==========================================

    def _load_config(self):
        """加载配置（合并 config.json + config_enhanced.json）"""
        config_path = Path(__file__).parent / "data" / "config.json"
        enhanced_path = Path(__file__).parent / "data" / "config_enhanced.json"
        try:
            if config_path.exists():
                with open(config_path, "r", encoding="utf-8") as f:
                    self._config = json.load(f)
                    
                self._room_id = self._config.get("room_id", self._room_id)
                self._interval = self._config.get("interval_seconds", self._interval)
                self._target_lanlan = self._config.get("target_lanlan", self._target_lanlan)
                self._danmaku_max_length = self._config.get("danmaku_max_length", self._danmaku_max_length)
                self._master_bili_uid = self._config.get("master_bili_uid", self._master_bili_uid)
                self._master_bili_name = self._config.get("master_bili_name", self._master_bili_name)
                
                # 合并增强配置（background_llm 等）
                if enhanced_path.exists():
                    try:
                        with open(enhanced_path, "r", encoding="utf-8") as f:
                            enhanced = json.load(f)
                        # 只合并 _config 中没有的顶层字段
                        for k, v in enhanced.items():
                            if k not in self._config and not k.startswith("_"):
                                self._config[k] = v
                        self.logger.info(f"增强配置已合并: background_llm={'已启用' if self._config.get('background_llm', {}).get('enabled') else '未启用'}")
                    except Exception as e:
                        self.logger.warning(f"增强配置加载失败: {e}")
                
                self.logger.info(f"配置加载成功: room_id={self._room_id}, interval={self._interval}")
            else:
                self._config = {}
                self.logger.warning("配置文件不存在，使用默认配置")
                
        except Exception as e:
            self.logger.error(f"配置加载失败: {e}")
            self._config = {}

    def _save_config(self):
        """保存配置"""
        config_path = Path(__file__).parent / "data" / "config.json"
        try:
            config_data = {
                "room_id": self._room_id,
                "interval_seconds": self._interval,
                "target_lanlan": self._target_lanlan,
                "danmaku_max_length": self._danmaku_max_length,
                "master_bili_uid": self._master_bili_uid,
                "master_bili_name": self._master_bili_name,
                **self._config  # 保留其他配置
            }
            
            config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(config_data, f, ensure_ascii=False, indent=2)
                
            self.logger.info("配置保存成功")
            
        except Exception as e:
            self.logger.error(f"配置保存失败: {e}")

    # ==========================================
    # 辅助方法
    # ==========================================

    def _push_to_ai(self, content: str, description: str, priority: int = 5):
        """推送消息给AI（同步方法，push_message 不是协程）"""
        try:
            self.logger.info(f"_push_to_ai 调用: description={description}, priority={priority}, content_len={len(content)}")
            self.push_message(
                source=self.name,
                message_type="proactive_notification",
                description=description,
                content=content,
                priority=priority,
                metadata={
                    "room_id": self._room_id,
                    "plugin": self.name,
                    "timestamp": datetime.now().isoformat()
                }
            )
            self.logger.info(f"_push_to_ai 成功: {description}")
        except Exception as e:
            self.logger.error(f"推送消息给AI失败: {e}")

    def _get_connection_info(self) -> dict:
        """获取连接详情"""
        if self._listener:
            return self._listener.get_connection_state()
        return {"connected": False, "reason": "no_listener"}